# 12-Hour Hackathon Checklist

## Phase 1: Foundation (Hours 1-3)
### Hour 1 - Setup
- [ ] Project folder created
- [ ] Virtual environment active
- [ ] Dependencies installed
- [ ] SQLite database initialized

### Hour 2 - Data Layer
- [ ] Tables created (control_library, findings, audit_log, mock_comms)
- [ ] PCI DSS controls loaded (20-30 rules)
- [ ] Mock communications generated (50+ messages)

### Hour 3 - Detection Engine
- [ ] Credit card regex working
- [ ] SSN regex working
- [ ] Luhn validation working
- [ ] Confidence scoring working
- [ ] Unit tests passing

---

## Phase 2: Agents (Hours 4-7)
### Hour 4 - Event Bus
- [ ] Redis running
- [ ] Pub/Sub class working
- [ ] Events publishing
- [ ] Events receiving

### Hour 5 - Watcher Agent
- [ ] Base Agent class done
- [ ] WatcherAgent reads mock updates
- [ ] Publishes `new_regulation` event

### Hour 6 - Interpreter + Monitor
- [ ] InterpreterAgent extracts controls
- [ ] MonitorAgent scans communications
- [ ] Detections logged to findings table
- [ ] `violation_detected` event published

### Hour 7 - Remediator
- [ ] RemediatorAgent receives events
- [ ] Generates remediation text
- [ ] Masks sensitive data
- [ ] Audit log entry created
- [ ] Full chain tested

---

## Phase 3: AI Layer (Hours 8-9)
### Hour 8 - Vector Store
- [ ] Sentence transformers installed
- [ ] Controls embedded
- [ ] FAISS index built
- [ ] Query function working

### Hour 9 - Gemini Integration
- [ ] API key configured
- [ ] Control extraction prompt
- [ ] Remediation prompt
- [ ] Q&A prompt
- [ ] Caching implemented

---

## Phase 4: Dashboard (Hours 10-12)
### Hour 10 - Core UI
- [ ] Streamlit app running
- [ ] Navigation sidebar
- [ ] Compliance score display
- [ ] Findings table

### Hour 11 - Features
- [ ] Live monitor tab
- [ ] Manual scan tab
- [ ] Ask regulations tab (RAG)

### Hour 12 - Demo Ready
- [ ] All components connected
- [ ] Demo scenario 1 works (reg update)
- [ ] Demo scenario 2 works (violation scan)
- [ ] Demo scenario 3 works (Q&A)
- [ ] Backup video recorded

---

## Final Checks
- [ ] No hardcoded API keys in code
- [ ] README with run instructions
- [ ] Demo script practiced
- [ ] Fallback plan ready

---

## Emergency Priorities (If Running Out of Time)

**Must Have (Hours 1-8):**
1. Detection pipeline
2. 2 working agents (Watcher + Monitor)
3. Basic Streamlit showing findings

**Can Skip:**
- RAG Q&A (show static demo)
- Remediator Agent (show concept)
- Live WebSocket updates
- Charts/visualizations

---

## Quick Debug Commands

```bash
# Check Redis
redis-cli ping

# Check database
sqlite3 complianceguard.db ".tables"

# Test detection
python -c "from detection.pipeline import scan; print(scan('Card: 4532123456789012'))"

# Check Gemini API
python -c "import google.generativeai as genai; print('API OK')"
```
