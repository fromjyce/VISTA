# Team Work Distribution (3 Members)
## 12-Hour Hackathon Sprint

---

## Team Roles

| Role | Focus | Primary Deliverables |
|------|-------|---------------------|
| **Dev 1: Backend Lead** | Detection + Agents | Detection pipeline, Agent framework, Event bus |
| **Dev 2: AI/Data Lead** | AI + Database | Gemini integration, RAG, SQLite, Mock data |
| **Dev 3: Frontend Lead** | Dashboard + Demo | Streamlit UI, Integration, Demo preparation |

---

## Hour-by-Hour Breakdown

### Phase 1: Foundation (Hours 1-3)

#### Dev 1 (Backend)
| Hour | Task | Output |
|------|------|--------|
| 1 | Project setup, folder structure | `complianceguard/` skeleton |
| 2 | Detection patterns (regex) | `detection/patterns.py` |
| 3 | Luhn validator, confidence scoring | `detection/validators.py`, `detection/pipeline.py` |

#### Dev 2 (AI/Data)
| Hour | Task | Output |
|------|------|--------|
| 1 | SQLite schema creation | `database/schema.sql`, `database/db.py` |
| 2 | PCI DSS controls data entry | 20-30 controls in database |
| 3 | Mock communications generator | `database/seed_data.py`, 50+ mock messages |

#### Dev 3 (Frontend)
| Hour | Task | Output |
|------|------|--------|
| 1 | Streamlit app skeleton | `dashboard/app.py` with navigation |
| 2 | Overview page layout | Metrics cards, placeholder charts |
| 3 | Manual scanner page | Text input + scan button UI |

**Sync Point (End of Hour 3):** 15-min standup
- Dev 1 demos detection on sample text
- Dev 2 shows populated database
- Dev 3 shows basic UI navigation

---

### Phase 2: Core Features (Hours 4-7)

#### Dev 1 (Backend)
| Hour | Task | Output |
|------|------|--------|
| 4 | Redis setup, EventBus class | `events/bus.py` |
| 5 | Base Agent class | `agents/base.py` |
| 6 | WatcherAgent + MonitorAgent | `agents/watcher.py`, `agents/monitor.py` |
| 7 | RemediatorAgent | `agents/remediator.py` |

#### Dev 2 (AI/Data)
| Hour | Task | Output |
|------|------|--------|
| 4 | Gemini API setup, test connection | `ai/gemini.py` |
| 5 | Control extraction prompt | `extract_controls()` function |
| 6 | Remediation suggestion prompt | `suggest_remediation()` function |
| 7 | Sentence transformers + FAISS index | `ai/embeddings.py`, `ai/rag.py` |

#### Dev 3 (Frontend)
| Hour | Task | Output |
|------|------|--------|
| 4 | Connect scanner to detection pipeline | Working scan feature |
| 5 | Findings table with real data | SQLite → DataFrame → Table |
| 6 | Violations pie chart | Plotly chart by entity type |
| 7 | Compliance score calculation | Dynamic score based on findings |

**Sync Point (End of Hour 7):** 15-min standup
- Dev 1 demos agent chain (trigger → events → actions)
- Dev 2 demos Gemini generating remediation
- Dev 3 demos dashboard with real findings data

---

### Phase 3: Integration (Hours 8-10)

#### Dev 1 (Backend)
| Hour | Task | Output |
|------|------|--------|
| 8 | InterpreterAgent (uses Gemini) | `agents/interpreter.py` |
| 9 | Full agent chain test | All 4 agents working together |
| 10 | Bug fixes, edge cases | Stable agent system |

#### Dev 2 (AI/Data)
| Hour | Task | Output |
|------|------|--------|
| 8 | RAG query function | `rag.query()` working |
| 9 | Q&A prompt with context | `answer_regulation_query()` |
| 10 | Help Frontend with AI integration | Support Dev 3 |

#### Dev 3 (Frontend)
| Hour | Task | Output |
|------|------|--------|
| 8 | "Ask Regulations" page | RAG Q&A interface |
| 9 | Live Monitor page (agent activity) | Real-time log display |
| 10 | "Trigger Scan" and "Trigger Update" buttons | Dashboard → Agent triggers |

**Sync Point (End of Hour 10):** 20-min integration test
- Run full demo scenario 1-2-3
- Identify critical bugs

---

### Phase 4: Demo Prep (Hours 11-12)

#### Dev 1 (Backend)
| Hour | Task | Output |
|------|------|--------|
| 11 | Fix critical bugs from integration | Stable system |
| 12 | Support demo, handle edge cases | Ready for presentation |

#### Dev 2 (AI/Data)
| Hour | Task | Output |
|------|------|--------|
| 11 | Prepare demo data (good examples) | Curated test cases |
| 12 | Technical Q&A prep | Ready to explain AI/RAG |

#### Dev 3 (Frontend)
| Hour | Task | Output |
|------|------|--------|
| 11 | UI polish, error handling | Clean demo experience |
| 12 | Record backup video, final testing | Fallback ready |

---

## Parallel Workstreams Diagram

```
Hour:  1   2   3   4   5   6   7   8   9  10  11  12
       │   │   │   │   │   │   │   │   │   │   │   │
Dev 1: [--Project Setup--][---Detection---][----Agents----|---Integration---|Fix]
Dev 2: [---Database + Mock Data---][----Gemini + RAG----|---Support--------|Q&A]
Dev 3: [---UI Skeleton---][---Dashboard Features---][---Integration + Polish---|Demo]
                   ↑               ↑                   ↑
               Sync #1         Sync #2            Sync #3
```

---

## Dependencies & Handoffs

| From | To | What | When |
|------|-----|------|------|
| Dev 2 | Dev 1 | Database ready for agents | End of Hour 2 |
| Dev 1 | Dev 3 | Detection pipeline for scanner | End of Hour 3 |
| Dev 1 | Dev 2 | Event bus for AI integration | End of Hour 4 |
| Dev 2 | Dev 3 | Gemini functions for dashboard | End of Hour 7 |
| Dev 1 | Dev 3 | Agent triggers for UI buttons | End of Hour 9 |
| Dev 2 | Dev 3 | RAG query for Q&A page | End of Hour 9 |

---

## Communication Protocol

### Slack/Discord Channels
- `#general` - Quick questions, blockers
- `#sync` - Sync point summaries
- `#bugs` - Issues found during integration

### Blocker Escalation
1. Try for 10 minutes alone
2. Post in `#general` with error message
3. If no response in 5 min, verbal interrupt
4. If >20 min blocked, simplify/skip feature

---

## Individual Checklists

### Dev 1 Checklist
- [ ] Project structure created
- [ ] Detection regex patterns working
- [ ] Luhn validation passing
- [ ] Redis connected
- [ ] EventBus pub/sub working
- [ ] BaseAgent class done
- [ ] WatcherAgent emits events
- [ ] MonitorAgent scans + logs findings
- [ ] RemediatorAgent generates suggestions
- [ ] InterpreterAgent extracts controls
- [ ] Full agent chain tested

### Dev 2 Checklist
- [ ] SQLite schema created
- [ ] PCI DSS controls loaded
- [ ] Mock communications generated
- [ ] Gemini API connected
- [ ] Control extraction working
- [ ] Remediation suggestions working
- [ ] Sentence transformers installed
- [ ] FAISS index built
- [ ] RAG query returning results
- [ ] Q&A function working
- [ ] Demo data curated

### Dev 3 Checklist
- [ ] Streamlit running
- [ ] Navigation working
- [ ] Overview page with metrics
- [ ] Scanner page functional
- [ ] Findings table populated
- [ ] Pie chart rendering
- [ ] Compliance score calculating
- [ ] Q&A page integrated
- [ ] Trigger buttons working
- [ ] Live monitor showing activity
- [ ] UI polished for demo
- [ ] Backup video recorded

---

## Risk Assignments

| Risk | Owner | Mitigation |
|------|-------|------------|
| Redis won't start | Dev 1 | Use in-memory fallback queue |
| Gemini rate limited | Dev 2 | Cache responses, mock for demo |
| spaCy download slow | Dev 2 | Pre-download, skip if needed |
| UI integration breaks | Dev 3 | Static demo mode fallback |
| Running out of time | ALL | Cut RAG Q&A first, keep core detection |

---

## Demo Responsibilities

| Scenario | Primary | Backup |
|----------|---------|--------|
| 1. Regulatory Update Flow | Dev 1 | Dev 2 |
| 2. Violation Detection | Dev 3 | Dev 1 |
| 3. RAG Q&A | Dev 2 | Dev 3 |
| Technical Q&A | Dev 2 | Dev 1 |
| Business Q&A | Dev 3 | Anyone |

---

## Final Hour Checklist (All Team)

- [ ] Demo scenario 1 works end-to-end
- [ ] Demo scenario 2 works end-to-end
- [ ] Demo scenario 3 works (or have excuse ready)
- [ ] No API keys in visible code
- [ ] Can restart system in <30 seconds if crash
- [ ] Each person can explain their part
- [ ] One person designated as "demo driver"
- [ ] Backup video exists on phone

---

**Golden Rule: Working > Perfect. Ship something that runs!**
