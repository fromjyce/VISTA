# Code Snippets Reference
## Copy-paste ready code for fast implementation

---

## 1. Database Schema (schema.sql)

```sql
-- Control Library
CREATE TABLE IF NOT EXISTS control_library (
    id TEXT PRIMARY KEY,
    requirement TEXT NOT NULL,
    description TEXT,
    category TEXT,
    version TEXT DEFAULT '4.0',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Findings
CREATE TABLE IF NOT EXISTS findings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_id TEXT,
    source_type TEXT,
    entity_type TEXT,
    entity_value TEXT,
    masked_value TEXT,
    confidence REAL,
    control_id TEXT,
    status TEXT DEFAULT 'open',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (control_id) REFERENCES control_library(id)
);

-- Audit Log
CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_name TEXT,
    action TEXT,
    details TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Mock Communications
CREATE TABLE IF NOT EXISTS mock_communications (
    id TEXT PRIMARY KEY,
    type TEXT,
    sender TEXT,
    recipient TEXT,
    subject TEXT,
    body TEXT,
    timestamp TIMESTAMP
);
```

---

## 2. Detection Patterns (detection/patterns.py)

```python
import re
from typing import List, Dict, Tuple

PATTERNS = {
    'credit_card': {
        'visa': r'\b4[0-9]{3}[-\s]?[0-9]{4}[-\s]?[0-9]{4}[-\s]?[0-9]{4}\b',
        'mastercard': r'\b5[1-5][0-9]{2}[-\s]?[0-9]{4}[-\s]?[0-9]{4}[-\s]?[0-9]{4}\b',
        'amex': r'\b3[47][0-9]{2}[-\s]?[0-9]{6}[-\s]?[0-9]{5}\b',
    },
    'ssn': r'\b[0-9]{3}[-\s]?[0-9]{2}[-\s]?[0-9]{4}\b',
    'email': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
    'phone': r'\b(?:\+1[-.\s]?)?\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}\b',
}

def luhn_check(card_number: str) -> bool:
    """Validate card number using Luhn algorithm."""
    digits = [int(d) for d in card_number if d.isdigit()]
    if len(digits) < 13:
        return False

    checksum = 0
    for i, digit in enumerate(reversed(digits)):
        if i % 2 == 1:
            digit *= 2
            if digit > 9:
                digit -= 9
        checksum += digit
    return checksum % 10 == 0

def detect_pci_pii(text: str) -> List[Dict]:
    """Detect all PCI/PII entities in text."""
    findings = []

    # Credit cards
    for card_type, pattern in PATTERNS['credit_card'].items():
        for match in re.finditer(pattern, text):
            value = match.group()
            clean = re.sub(r'[-\s]', '', value)
            if luhn_check(clean):
                findings.append({
                    'type': 'credit_card',
                    'subtype': card_type,
                    'value': value,
                    'start': match.start(),
                    'end': match.end(),
                    'confidence': 0.95
                })

    # SSN
    for match in re.finditer(PATTERNS['ssn'], text):
        findings.append({
            'type': 'ssn',
            'value': match.group(),
            'start': match.start(),
            'end': match.end(),
            'confidence': 0.85
        })

    # Email
    for match in re.finditer(PATTERNS['email'], text):
        findings.append({
            'type': 'email',
            'value': match.group(),
            'start': match.start(),
            'end': match.end(),
            'confidence': 0.90
        })

    return findings

def mask_value(value: str, entity_type: str) -> str:
    """Mask sensitive value for safe display."""
    if entity_type == 'credit_card':
        clean = re.sub(r'[-\s]', '', value)
        return f"****-****-****-{clean[-4:]}"
    elif entity_type == 'ssn':
        return "***-**-" + value[-4:]
    elif entity_type == 'email':
        parts = value.split('@')
        return f"{parts[0][:2]}***@{parts[1]}"
    return "***MASKED***"
```

---

## 3. Event Bus (events/bus.py)

```python
import redis
import json
from typing import Callable, Dict, Any
from datetime import datetime

class EventBus:
    def __init__(self, host='localhost', port=6379):
        self.redis = redis.Redis(host=host, port=port, decode_responses=True)
        self.pubsub = self.redis.pubsub()
        self.handlers: Dict[str, Callable] = {}

    def publish(self, channel: str, event: Dict[str, Any]):
        """Publish event to channel."""
        event['timestamp'] = datetime.utcnow().isoformat()
        self.redis.publish(channel, json.dumps(event))
        print(f"[EventBus] Published to {channel}: {event.get('type', 'unknown')}")

    def subscribe(self, channel: str, handler: Callable):
        """Subscribe to channel with handler."""
        self.handlers[channel] = handler
        self.pubsub.subscribe(**{channel: self._wrap_handler(handler)})

    def _wrap_handler(self, handler: Callable):
        def wrapper(message):
            if message['type'] == 'message':
                data = json.loads(message['data'])
                handler(data)
        return wrapper

    def listen(self):
        """Start listening for events (blocking)."""
        print("[EventBus] Listening for events...")
        for message in self.pubsub.listen():
            pass  # Handlers called automatically

# Event schemas
class Events:
    NEW_REGULATION = 'new_regulation'
    CONTROLS_UPDATED = 'controls_updated'
    VIOLATION_DETECTED = 'violation_detected'
    REMEDIATION_COMPLETE = 'remediation_complete'
    SCAN_REQUESTED = 'scan_requested'
```

---

## 4. Base Agent (agents/base.py)

```python
from abc import ABC, abstractmethod
from events.bus import EventBus
import sqlite3
from datetime import datetime

class BaseAgent(ABC):
    def __init__(self, name: str, event_bus: EventBus, db_path: str = 'complianceguard.db'):
        self.name = name
        self.event_bus = event_bus
        self.db_path = db_path

    @abstractmethod
    def process(self, event: dict):
        """Process incoming event."""
        pass

    def log_action(self, action: str, details: str):
        """Log agent action to audit trail."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO audit_log (agent_name, action, details) VALUES (?, ?, ?)",
            (self.name, action, details)
        )
        conn.commit()
        conn.close()
        print(f"[{self.name}] {action}: {details[:50]}...")

    def emit(self, channel: str, event_type: str, data: dict):
        """Emit event to bus."""
        self.event_bus.publish(channel, {
            'type': event_type,
            'source': self.name,
            'data': data
        })
```

---

## 5. Monitor Agent (agents/monitor.py)

```python
from agents.base import BaseAgent
from detection.patterns import detect_pci_pii, mask_value
from events.bus import Events
import sqlite3

class MonitorAgent(BaseAgent):
    def __init__(self, event_bus, db_path='complianceguard.db'):
        super().__init__('MonitorAgent', event_bus, db_path)
        # Subscribe to scan requests
        event_bus.subscribe('scan_requested', self.process)

    def process(self, event: dict):
        self.log_action('scan_started', f"Scanning {event.get('data', {}).get('count', 'all')} communications")

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Get unscanned communications
        cursor.execute("SELECT id, type, body FROM mock_communications")
        messages = cursor.fetchall()

        total_findings = 0
        for msg_id, msg_type, body in messages:
            findings = detect_pci_pii(body)

            for finding in findings:
                cursor.execute('''
                    INSERT INTO findings (source_id, source_type, entity_type, entity_value, masked_value, confidence)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (
                    msg_id, msg_type, finding['type'],
                    finding['value'], mask_value(finding['value'], finding['type']),
                    finding['confidence']
                ))
                total_findings += 1

                # Emit violation event
                self.emit('violation_detected', Events.VIOLATION_DETECTED, {
                    'source_id': msg_id,
                    'entity_type': finding['type'],
                    'confidence': finding['confidence']
                })

        conn.commit()
        conn.close()

        self.log_action('scan_complete', f"Found {total_findings} violations in {len(messages)} messages")
```

---

## 6. Gemini Integration (ai/gemini.py)

```python
import google.generativeai as genai
from functools import lru_cache
import os

genai.configure(api_key=os.getenv('GEMINI_API_KEY'))
model = genai.GenerativeModel('gemini-pro')

@lru_cache(maxsize=100)
def extract_controls(regulation_text: str) -> str:
    """Extract compliance controls from regulation text."""
    prompt = f"""Analyze this regulatory update and extract specific compliance controls.

Regulation:
{regulation_text}

Return as JSON array with format:
[{{"id": "3.4.1", "requirement": "...", "description": "..."}}]

Only return the JSON, no explanation."""

    response = model.generate_content(prompt)
    return response.text

@lru_cache(maxsize=100)
def suggest_remediation(violation_type: str, context: str) -> str:
    """Generate remediation suggestion for violation."""
    prompt = f"""A {violation_type} was found in business communication.

Context: {context[:200]}

Provide a brief remediation suggestion (2-3 sentences) for PCI DSS compliance.
Focus on: immediate action, policy update, prevention."""

    response = model.generate_content(prompt)
    return response.text

def answer_regulation_query(question: str, context: str) -> str:
    """Answer question using RAG context."""
    prompt = f"""Based on these PCI DSS requirements:

{context}

Answer this question: {question}

Be specific and cite requirement numbers. Keep response under 100 words."""

    response = model.generate_content(prompt)
    return response.text
```

---

## 7. RAG Setup (ai/rag.py)

```python
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
import sqlite3

class RegulationRAG:
    def __init__(self, db_path='complianceguard.db'):
        self.model = SentenceTransformer('all-MiniLM-L6-v2')
        self.db_path = db_path
        self.index = None
        self.controls = []
        self._build_index()

    def _build_index(self):
        """Build FAISS index from control library."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT id, requirement, description FROM control_library")
        rows = cursor.fetchall()
        conn.close()

        self.controls = []
        texts = []
        for row in rows:
            self.controls.append({'id': row[0], 'requirement': row[1], 'description': row[2]})
            texts.append(f"{row[1]} {row[2]}")

        if texts:
            embeddings = self.model.encode(texts)
            self.index = faiss.IndexFlatL2(embeddings.shape[1])
            self.index.add(embeddings.astype('float32'))

    def query(self, question: str, k: int = 5) -> list:
        """Find most relevant controls for question."""
        if not self.index:
            return []

        query_embedding = self.model.encode([question])
        distances, indices = self.index.search(query_embedding.astype('float32'), k)

        results = []
        for idx in indices[0]:
            if idx < len(self.controls):
                results.append(self.controls[idx])
        return results
```

---

## 8. Streamlit Dashboard (dashboard/app.py)

```python
import streamlit as st
import sqlite3
import pandas as pd
import plotly.express as px
from detection.patterns import detect_pci_pii, mask_value

st.set_page_config(page_title="ComplianceGuard AI", layout="wide")

def get_db_connection():
    return sqlite3.connect('complianceguard.db')

# Sidebar
st.sidebar.title("ComplianceGuard AI")
page = st.sidebar.radio("Navigate", ["Overview", "Live Monitor", "Scan Content", "Ask Regulations"])

if page == "Overview":
    st.title("Compliance Dashboard")

    conn = get_db_connection()

    # Metrics
    col1, col2, col3, col4 = st.columns(4)

    total_findings = pd.read_sql("SELECT COUNT(*) as count FROM findings", conn).iloc[0]['count']
    open_findings = pd.read_sql("SELECT COUNT(*) as count FROM findings WHERE status='open'", conn).iloc[0]['count']
    controls_count = pd.read_sql("SELECT COUNT(*) as count FROM control_library", conn).iloc[0]['count']

    score = max(0, 100 - (open_findings * 5))  # Simple scoring

    col1.metric("Compliance Score", f"{score}%", delta="-5%" if open_findings > 0 else "+0%")
    col2.metric("Open Violations", open_findings)
    col3.metric("Total Findings", total_findings)
    col4.metric("Active Controls", controls_count)

    # Charts
    st.subheader("Violations by Type")
    findings_df = pd.read_sql(
        "SELECT entity_type, COUNT(*) as count FROM findings GROUP BY entity_type",
        conn
    )
    if not findings_df.empty:
        fig = px.pie(findings_df, values='count', names='entity_type')
        st.plotly_chart(fig)

    # Recent findings table
    st.subheader("Recent Findings")
    recent = pd.read_sql(
        "SELECT source_type, entity_type, masked_value, confidence, status, created_at FROM findings ORDER BY created_at DESC LIMIT 10",
        conn
    )
    st.dataframe(recent)

    conn.close()

elif page == "Scan Content":
    st.title("Manual Content Scanner")

    text_input = st.text_area("Paste content to scan:", height=200)

    if st.button("Scan for PCI/PII"):
        if text_input:
            findings = detect_pci_pii(text_input)

            if findings:
                st.error(f"Found {len(findings)} sensitive items!")

                for f in findings:
                    col1, col2, col3 = st.columns(3)
                    col1.write(f"**Type:** {f['type']}")
                    col2.write(f"**Masked:** {mask_value(f['value'], f['type'])}")
                    col3.write(f"**Confidence:** {f['confidence']*100:.0f}%")
            else:
                st.success("No PCI/PII data detected!")
        else:
            st.warning("Please enter text to scan")

elif page == "Ask Regulations":
    st.title("Regulation Q&A")

    question = st.text_input("Ask about PCI DSS requirements:")

    if st.button("Ask") and question:
        from ai.rag import RegulationRAG
        from ai.gemini import answer_regulation_query

        rag = RegulationRAG()
        relevant = rag.query(question, k=3)

        context = "\n".join([f"{c['id']}: {c['requirement']}" for c in relevant])
        answer = answer_regulation_query(question, context)

        st.write("### Answer")
        st.write(answer)

        st.write("### Related Controls")
        for c in relevant:
            st.info(f"**{c['id']}**: {c['requirement']}")
```

---

## 9. Mock Data Generator (database/seed_data.py)

```python
import sqlite3
import json
import random

def seed_database(db_path='complianceguard.db'):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Load schema
    with open('database/schema.sql', 'r') as f:
        cursor.executescript(f.read())

    # Sample PCI DSS controls
    controls = [
        ("3.4", "Render PAN unreadable anywhere it is stored", "Use encryption, hashing, or truncation"),
        ("3.4.1", "Use strong cryptography for PAN storage", "AES-256 or equivalent"),
        ("3.5.1", "Restrict access to cryptographic keys", "Least privilege principle"),
        ("4.1", "Use strong cryptography for transmission", "TLS 1.2+ required"),
        ("4.2", "Never send unprotected PANs by end-user messaging", "Email, chat, SMS prohibited"),
        ("7.1", "Limit access to system components", "Need-to-know basis only"),
        ("8.3", "Secure all authentication", "MFA required for remote access"),
        ("10.1", "Implement audit trails", "Link actions to individual users"),
        ("12.6", "Security awareness training", "Annual training required"),
    ]

    for c in controls:
        cursor.execute(
            "INSERT OR IGNORE INTO control_library (id, requirement, description) VALUES (?, ?, ?)",
            c
        )

    # Mock communications with PCI/PII data
    templates = [
        ("email", "Hi, please process payment for card 4532-1234-5678-9012. Thanks!"),
        ("email", "Customer SSN 123-45-6789 needs account update"),
        ("chat", "Can you check card ending 4532123456789012 for fraud?"),
        ("email", "My Amex 371234567890125 was declined, help!"),
        ("chat", "Send refund to john.doe@email.com please"),
        ("email", "Here's my info: SSN 987-65-4321, card 5412-7534-9821-0034"),
        ("chat", "Normal message with no sensitive data"),
        ("email", "Please call me at 555-123-4567 about the invoice"),
    ]

    for i, (msg_type, body) in enumerate(templates * 5):  # Create 40 messages
        cursor.execute(
            "INSERT INTO mock_communications (id, type, sender, recipient, subject, body) VALUES (?, ?, ?, ?, ?, ?)",
            (f"MSG-{i:03d}", msg_type, f"user{i}@company.com", "support@company.com", "Support Request", body)
        )

    conn.commit()
    conn.close()
    print("Database seeded successfully!")

if __name__ == "__main__":
    seed_database()
```

---

## 10. Main Entry Point (main.py)

```python
import argparse
import threading
from events.bus import EventBus
from agents.watcher import WatcherAgent
from agents.interpreter import InterpreterAgent
from agents.monitor import MonitorAgent
from agents.remediator import RemediatorAgent

def start_agents():
    """Start all agents and event bus."""
    print("Starting ComplianceGuard AI Agents...")

    # Initialize event bus
    event_bus = EventBus()

    # Initialize agents
    agents = [
        WatcherAgent(event_bus),
        InterpreterAgent(event_bus),
        MonitorAgent(event_bus),
        RemediatorAgent(event_bus),
    ]

    print(f"Initialized {len(agents)} agents")

    # Start listening (blocking)
    event_bus.listen()

def trigger_scan():
    """Manually trigger a compliance scan."""
    event_bus = EventBus()
    event_bus.publish('scan_requested', {
        'type': 'manual_scan',
        'source': 'CLI',
        'data': {'count': 'all'}
    })
    print("Scan triggered!")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--start-agents', action='store_true')
    parser.add_argument('--trigger-scan', action='store_true')
    args = parser.parse_args()

    if args.start_agents:
        start_agents()
    elif args.trigger_scan:
        trigger_scan()
    else:
        print("Use --start-agents or --trigger-scan")
```

---

**Copy these snippets and adapt as needed. Good luck!**
