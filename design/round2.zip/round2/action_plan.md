# ComplianceGuard AI - Round 2 Action Plan
## 12-Hour Prototype Development

---

## Objective
Build a **working functional prototype** demonstrating core value: AI agents that detect PCI/PII violations and auto-remediate with audit trails. Focus on **demonstrable functionality** over polish.

---

## Scope Decision Matrix

### BUILD (Must Have for Demo)
| Module | Why Essential |
|--------|---------------|
| Detection Pipeline | Core value prop - finds sensitive data |
| 2-3 Working Agents | Shows "agentic AI" concept |
| SQLite Control Library | Pre-loaded PCI DSS rules |
| Streamlit Dashboard | Visual demo for judges |
| Mock Data Generator | Simulates real scenarios |
| Event Bus (Redis) | Shows agent communication |

### SKIP (Remove from Prototype)
| Module | Why Skip |
|--------|----------|
| Visa API Integration | Complex auth, not core demo |
| Real Email/Slack/O365 APIs | OAuth complexity, rate limits |
| Prophet Forecasting | Nice-to-have, not core |
| XGBoost Risk Model | Simple scoring sufficient |
| Constitutional AI Debate | Simplify to single LLM call |
| Real RSS Polling | Mock regulatory updates |

---

## Architecture (Simplified for 12 Hours)

```
┌─────────────────────────────────────────────────────────────┐
│                    STREAMLIT DASHBOARD                       │
│  [Compliance Score] [Live Detections] [Agent Activity Log]  │
└─────────────────────────────────────────────────────────────┘
                              │
┌─────────────────────────────────────────────────────────────┐
│                     REDIS EVENT BUS                          │
│         (Pub/Sub channels for agent communication)           │
└─────────────────────────────────────────────────────────────┘
         │              │              │              │
    ┌────┴────┐   ┌────┴────┐   ┌────┴────┐   ┌────┴────┐
    │ WATCHER │   │INTERPRET│   │ MONITOR │   │REMEDIATE│
    │  AGENT  │   │  AGENT  │   │  AGENT  │   │  AGENT  │
    └─────────┘   └─────────┘   └─────────┘   └─────────┘
                              │
┌─────────────────────────────────────────────────────────────┐
│                    AI/ML SERVICES                            │
│  [Gemini API] [Regex Engine] [spaCy NER] [FAISS RAG]        │
└─────────────────────────────────────────────────────────────┘
                              │
┌─────────────────────────────────────────────────────────────┐
│                    SQLITE DATABASE                           │
│  [control_library] [findings] [audit_log] [mock_data]       │
└─────────────────────────────────────────────────────────────┘
```

---

## 12-Hour Timeline

### Phase 1: Foundation (Hours 1-3)
**Goal: Project skeleton + data layer working**

#### Hour 1: Project Setup
- [ ] Create project structure
- [ ] Set up virtual environment
- [ ] Install dependencies (requirements.txt)
- [ ] Initialize SQLite database

#### Hour 2: Database Schema + Mock Data
- [ ] Create `control_library` table (PCI DSS rules)
- [ ] Create `findings` table (detected violations)
- [ ] Create `audit_log` table (agent actions)
- [ ] Create `mock_communications` table
- [ ] Load 20-30 PCI DSS controls from sample data
- [ ] Generate 50+ mock messages (emails, chats with PCI/PII)

#### Hour 3: Detection Engine Core
- [ ] Implement regex patterns for:
  - Credit card numbers (Visa, MC, Amex)
  - SSN patterns
  - Email addresses
  - Phone numbers
- [ ] Add Luhn algorithm validation for card numbers
- [ ] Create confidence scoring function
- [ ] Unit test with mock data

---

### Phase 2: Agent Framework (Hours 4-7)
**Goal: Agents communicating via events**

#### Hour 4: Redis Setup + Event Bus
- [ ] Start Redis server (or use Docker)
- [ ] Create `EventBus` class with pub/sub
- [ ] Define event schema (JSON format)
- [ ] Test publish/subscribe flow

#### Hour 5: Watcher Agent
- [ ] Create base `Agent` class
- [ ] Implement `WatcherAgent`:
  - Reads mock regulatory updates
  - Publishes `new_regulation` event
- [ ] Test agent lifecycle

#### Hour 6: Interpreter + Monitor Agents
- [ ] Implement `InterpreterAgent`:
  - Receives `new_regulation` event
  - Calls Gemini API to extract controls
  - Updates control_library
  - Publishes `controls_updated` event
- [ ] Implement `MonitorAgent`:
  - Scans mock_communications
  - Runs detection pipeline
  - Logs findings
  - Publishes `violation_detected` event

#### Hour 7: Remediator Agent
- [ ] Implement `RemediatorAgent`:
  - Receives `violation_detected` event
  - Generates remediation suggestion (Gemini)
  - Creates masked version of content
  - Logs to audit_log
  - Publishes `remediation_complete` event
- [ ] Test full agent chain

---

### Phase 3: RAG + Intelligence (Hours 8-9)
**Goal: Smart regulatory Q&A**

#### Hour 8: FAISS Vector Store
- [ ] Embed PCI DSS controls using sentence-transformers
- [ ] Build FAISS index
- [ ] Create `query_regulations(question)` function
- [ ] Test similarity search

#### Hour 9: Gemini Integration
- [ ] Set up Gemini Pro API
- [ ] Create prompt templates:
  - Control extraction prompt
  - Remediation suggestion prompt
  - Regulation Q&A prompt
- [ ] Add response caching (avoid rate limits)
- [ ] Test all LLM functions

---

### Phase 4: Dashboard + Demo (Hours 10-12)
**Goal: Impressive visual demo**

#### Hour 10: Streamlit Dashboard - Core
- [ ] Create main layout:
  - Sidebar: Navigation, trigger buttons
  - Main: Tabs for different views
- [ ] Build "Compliance Overview" tab:
  - Overall score gauge
  - Violations by category chart
  - Recent findings table

#### Hour 11: Dashboard - Live Features
- [ ] Build "Live Monitor" tab:
  - Real-time detection feed
  - Agent activity stream
- [ ] Build "Scan Content" tab:
  - Text input for manual scan
  - Show detected entities highlighted
- [ ] Build "Ask Regulations" tab:
  - RAG-powered Q&A interface

#### Hour 12: Integration + Polish
- [ ] Connect dashboard to Redis events
- [ ] Add WebSocket for live updates
- [ ] Prepare demo scenarios:
  1. Trigger regulatory update → watch agents react
  2. Scan sample email with card number
  3. Ask "What are PCI DSS encryption requirements?"
- [ ] Fix critical bugs
- [ ] Record backup demo video (if time)

---

## Project Structure

```
complianceguard/
├── main.py                 # Entry point
├── requirements.txt
├── config.py               # API keys, settings
├── database/
│   ├── __init__.py
│   ├── schema.sql
│   ├── db.py              # SQLite operations
│   └── seed_data.py       # Mock data generator
├── detection/
│   ├── __init__.py
│   ├── patterns.py        # Regex patterns
│   ├── validators.py      # Luhn, format checks
│   └── pipeline.py        # Detection orchestrator
├── agents/
│   ├── __init__.py
│   ├── base.py            # Base Agent class
│   ├── watcher.py
│   ├── interpreter.py
│   ├── monitor.py
│   └── remediator.py
├── events/
│   ├── __init__.py
│   ├── bus.py             # Redis pub/sub wrapper
│   └── schemas.py         # Event JSON schemas
├── ai/
│   ├── __init__.py
│   ├── gemini.py          # Gemini API client
│   ├── embeddings.py      # Sentence transformers
│   └── rag.py             # FAISS + retrieval
├── dashboard/
│   ├── app.py             # Streamlit main
│   ├── pages/
│   │   ├── overview.py
│   │   ├── monitor.py
│   │   ├── scanner.py
│   │   └── ask.py
│   └── components/
│       ├── charts.py
│       └── tables.py
└── mock_data/
    ├── regulations.json   # Sample reg updates
    ├── communications.json # Sample messages
    └── pci_dss_controls.json
```

---

## Dependencies (requirements.txt)

```
# Core
streamlit>=1.28.0
redis>=5.0.0
sqlite3  # Built-in

# AI/ML
google-generativeai>=0.3.0  # Gemini
sentence-transformers>=2.2.0
faiss-cpu>=1.7.4
spacy>=3.7.0

# Detection
phonenumbers>=8.13.0

# Visualization
plotly>=5.18.0
pandas>=2.1.0

# Utilities
python-dotenv>=1.0.0
pydantic>=2.5.0
```

---

## Mock Data Samples

### Sample Regulatory Update (mock)
```json
{
  "id": "REG-2024-001",
  "source": "PCI SSC",
  "title": "PCI DSS 4.0.1 Update",
  "date": "2024-12-15",
  "content": "Requirement 3.4.2 now mandates encryption of PAN at rest using AES-256...",
  "affected_controls": ["3.4", "3.4.1", "3.4.2"]
}
```

### Sample Communication (mock)
```json
{
  "id": "MSG-001",
  "type": "email",
  "from": "john@company.com",
  "to": "support@vendor.com",
  "subject": "Payment Issue",
  "body": "Hi, my card 4532-1234-5678-9012 was charged twice. My SSN is 123-45-6789. Please help.",
  "timestamp": "2024-12-20T10:30:00Z"
}
```

---

## Demo Script (For Presentation)

### Scenario 1: Regulatory Update Flow (2 min)
1. Click "Trigger Regulation Update" button
2. Show Watcher Agent detecting new update
3. Show Interpreter Agent extracting controls
4. Show Control Library updated with new rules
5. **Key Point**: "Agents autonomously process regulatory changes"

### Scenario 2: Violation Detection (2 min)
1. Click "Run Communication Scan"
2. Show Monitor Agent scanning messages
3. Show detected PAN/SSN highlighted
4. Show Remediator generating masked version
5. Show audit log entry
6. **Key Point**: "Automatic detection and remediation with full audit trail"

### Scenario 3: RAG Q&A (1 min)
1. Type: "What encryption is required for stored card data?"
2. Show RAG retrieving relevant PCI DSS sections
3. Show Gemini generating answer with citations
4. **Key Point**: "AI-powered regulatory knowledge assistant"

---

## Risk Mitigation

| Risk | Mitigation |
|------|------------|
| Gemini API rate limits | Cache responses, use mock for demo |
| Redis connection issues | Fallback to in-memory queue |
| spaCy model download slow | Pre-download, use small model |
| Time overrun | Cut RAG if needed, focus on detection |
| Demo crashes | Have backup screenshots/video |

---

## Success Criteria

**Minimum Viable Demo:**
- [ ] Detection pipeline finds PAN/SSN in text
- [ ] At least 2 agents communicate via events
- [ ] Dashboard shows compliance score + findings
- [ ] One full scan workflow works end-to-end

**Stretch Goals (if time permits):**
- [ ] All 4 agents working
- [ ] RAG Q&A functional
- [ ] Live WebSocket updates
- [ ] Highlighted entity visualization

---

## Team Task Assignment (If Team of 2-3)

| Person | Focus Area | Hours |
|--------|------------|-------|
| Dev 1 | Detection + Agents | 1-7 |
| Dev 2 | Dashboard + Demo | 8-12 |
| Dev 3 (if available) | AI/RAG + Integration | 6-12 |

**Solo Strategy:**
- Hours 1-7: Backend (detection, agents, events)
- Hours 8-12: Frontend (dashboard, integration)
- Prioritize working demo over feature completeness

---

## Quick Start Commands

```bash
# Setup
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows
pip install -r requirements.txt
python -m spacy download en_core_web_sm

# Initialize database
python database/seed_data.py

# Start Redis (Docker)
docker run -d -p 6379:6379 redis:alpine

# Run dashboard
streamlit run dashboard/app.py

# Run agents (separate terminal)
python main.py --start-agents
```

---

**Remember: A working demo that shows the concept beats a polished but broken prototype. Ship it!**
